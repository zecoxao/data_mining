update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='100'
where regiao_num_destino>='100' and regiao_num_destino<'300'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='101'
where regiao_num_destino>='300' and regiao_num_destino<'380'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='102'
where regiao_num_destino>='380' and regiao_num_destino<'440'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='201'
where regiao_num_destino>='440' and regiao_num_destino<'490'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='202'
where regiao_num_destino>='490' and regiao_num_destino<'530' 
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='203'
where regiao_num_destino>='530' and regiao_num_destino<'600'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='253'
where regiao_num_destino>='600' and regiao_num_destino<'710'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='252'
where regiao_num_destino>='710' and regiao_num_destino<'780'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='254'
where regiao_num_destino>='780' and regiao_num_destino<'820'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='255'
where regiao_num_destino>='820' and regiao_num_destino<'890'  
GO

update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_destino='256'
where regiao_num_destino>='820'
GO