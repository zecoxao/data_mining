update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='100'
where regiao_num_origem>='100' and regiao_num_origem<'300'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='101'
where regiao_num_origem>='300' and regiao_num_origem<'380'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='102'
where regiao_num_origem>='380' and regiao_num_origem<'440'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='201'
where regiao_num_origem>='440' and regiao_num_origem<'490'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='202'
where regiao_num_origem>='490' and regiao_num_origem<'530' 
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='203'
where regiao_num_origem>='530' and regiao_num_origem<'600'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='253'
where regiao_num_origem>='600' and regiao_num_origem<'710'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='252'
where regiao_num_origem>='710' and regiao_num_origem<'780'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='254'
where regiao_num_origem>='780' and regiao_num_origem<'820'  
GO
update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='255'
where regiao_num_origem>='820' and regiao_num_origem<'890'  
GO

update  [Tutorial-6-OperadoraTelefonica].[dbo].[TABELA_FACTOS_CHAMADAS]
set regiao_num_origem='256'
where regiao_num_origem>='820'
GO