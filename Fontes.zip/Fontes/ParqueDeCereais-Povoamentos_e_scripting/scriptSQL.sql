

 

Use ParqueCereais
Declare @portaAcesso CHAR(01)
Declare @n�meroAcesso INT
Declare @dataAcesso SMALLDATETIME
Declare @numeronovoacesso INT
Declare @datanovoacesso SMALLDATETIME
Declare @ContaPorta INT


SET @ContaPorta=1
While @ContaPorta<5 begin

      if @ContaPorta=1 begin set @portaAcesso='A'  end
      if @ContaPorta=2 begin set @portaAcesso='B'  end
      if @ContaPorta=3 begin set @portaAcesso='C'  end
      if @ContaPorta=4 begin set @portaAcesso='D'  end


     select @numeronovoacesso=n�meroregisto, @datanovoacesso=dataregisto
     from CTRecolhaRegistos where tabela=@portaacesso

     if @contaporta=1 begin
         select  top 1 @numeronovoacesso=n�mero,  @datanovoacesso=dataregisto 
              from registosport�oA order by n�mero desc

         delete  registosport�oA where n�mero<=@numeronovoacesso
     end
     

     if @contaporta=2 begin
         select  top 1 @numeronovoacesso=n�mero,  @datanovoacesso=dataregisto 
              from registosport�oB order by n�mero desc

         delete  registosport�oB where n�mero<=@numeronovoacesso
     end

     if @contaporta=3 begin
         select  top 1 @numeronovoacesso=n�mero,  @datanovoacesso=dataregisto 
              from registosport�oC order by n�mero desc

         delete  registosport�oC where n�mero<=@numeronovoacesso
     end

     if @contaporta=4 begin
         select  top 1 @numeronovoacesso=n�mero,  @datanovoacesso=dataregisto 
              from registosport�oA order by n�mero desc

         delete  registosport�oD where n�mero<=@numeronovoacesso
     end

 
      update ctrecolharegistos set n�meroregisto=@numeronovoacesso, dataregisto=@datanovoacesso
      where tabela=@datanovoacesso



   set @ContaPorta=@ContaPorta+1;
end;



