insert into RegistosEntrada          
SELECT        'A',pa.N�mero,pa.DataRegisto,pa.Empresa,pa.Ve�culo,pa.[Tipo Ve�culo],pa.[Tipo Carga],pa.Quantidade,
              pa.Armaz�m,pa.[Tipo Controlo],pa.Funcion�rio

FROM            RegistosPort�oA as pa CROSS JOIN
                         CTRecolhaRegistos
WHERE        n�mero not in (select N�meroRegisto
                               FROM            CTRecolhaRegistos
                              WHERE        CTRecolhaRegistos.tabela = '[a]'
                           )
                            